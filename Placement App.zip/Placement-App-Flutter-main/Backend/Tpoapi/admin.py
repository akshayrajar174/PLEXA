from django.contrib import admin

from Tpoapi.models import Student,Company,InterviewSchedule

admin.site.register(Student)
admin.site.register(Company)
admin.site.register(InterviewSchedule)
